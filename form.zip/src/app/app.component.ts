import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { ApiService } from './api.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'form';
  formdata: any;
  enablebutton = false;
  timespent = 0;
  fullname: any;
  showresendbutton = false;
  registrationdone = false;
  constructor(private api: ApiService) {

  }
  ngOnInit(): void {
    this.formdata = new FormGroup(
      {
        city: new FormControl("", Validators.required),
        panNumber: new FormControl("", Validators.required),
        fullname: new FormControl("", Validators.required),
        email: new FormControl("", Validators.compose([Validators.required, Validators.email])),
        mobile: new FormControl("", Validators.compose([Validators.required, Validators.pattern(/^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[789]\d{9}$/)])),
        otp: new FormControl("", Validators.compose([Validators.required, Validators.min(1000), Validators.max(9999)]))
      }
    );
  }
  sendOTP(formdata: any) {
    if (formdata.controls.mobile.invalid == false) {
      this.timespent = 0;
      let para = {
        "panNumber": formdata.controls.panNumber.value,
        "city": formdata.controls.city.value,
        "fullname": formdata.controls.fullname.value,
        "email": formdata.controls.email.value,
        "mobile": formdata.controls.mobile.value
      }

      this.api.post("http://apps.thinkoverit.com/api/getOTP.php", para).subscribe((data: any) => {
        if (data.status == "Success") {
          alert("OTP sent to this mobile no");
          let interval = setInterval(() => {
            this.timespent++;
            if (this.timespent < 180) {
              this.enablebutton = false;
              this.showresendbutton = false;
            }
            else {
              this.enablebutton = true;
              this.showresendbutton = true;
              clearInterval(interval);
            }
          }, 1000);
        }
        else{
          alert("Something went wrong.");
        }
      });
    }

  }
  verifyOTP(formdata: any) {

    if (formdata.invalid == false) {

      let para = {

        "mobile": "9874561230",
        "otp": "2222"
      }



      this.api.post("http://apps.thinkoverit.com/api/verifyOTP.php", para).subscribe(
        (data: any) => {
          this.registrationdone = true;
          this.fullname = formdata.controls.fullname.value;
        }
      );

    };
  }
}
